﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace project.Items
{
    public class GlobalFinancialItem
    {

        public int Mes
        {
            get;
            set;
        }
        public int Ano
        {
            get;
            set;
        }
        public double Vendas
        {
            get;
            set;
        }
        public double Compras
        {
            get;
            set;
        }

    }
}

