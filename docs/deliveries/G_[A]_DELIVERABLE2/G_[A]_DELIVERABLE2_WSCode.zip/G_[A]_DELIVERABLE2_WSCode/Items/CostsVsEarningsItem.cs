﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace project.Items
{
    public class CostsVsEarningsItem
    {
        public double totalCost
        {
            get;
            set;
        }

        public double totalEarning
        {
            get;
            set;
        }

        public double profit
        {
            get;
            set;
        }
    }
}