﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace project.Items
{
    public class SalesBookingItem
    {
        public string nome
        {
            get;
            set;
        }

        public double valorVendas
        {
            get;
            set;
        }

    }
}