﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace project.Items
{
    public class TopProductsItem
    {

        public string codArtigo
        {
            get;
            set;
        }
        public string description
        {
            get;
            set;
        }
        public double quantity
        {
            get;
            set;
        }
        public string percentage
        {
            get;
            set;
        }
        public double salesVolume
        {
            get;
            set;
        }

    }
}
