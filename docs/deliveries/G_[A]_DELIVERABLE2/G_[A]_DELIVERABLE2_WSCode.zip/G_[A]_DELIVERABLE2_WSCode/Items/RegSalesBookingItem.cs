﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace project.Items
{
    public class RegSalesBookingItem
    {
        public string pais
        {
            get;
            set;
        }

        public double valorVendas
        {
            get;
            set;
        }

    }
}