﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace project.Items
{
    public class RegionalSSItem
    {
        public string pais
        {
            get;
            set;
        }

        public double percentagem
        {
            get;
            set;
        }

    }
}
